#include <iostream>
#include "filter_tools.h"
#include "routing_table_hierarchy.h"
#include "routing_table_table.h"
#include "sorting_tool.h"

void showMenu() {
    std::cout << "======Menu======" << '\n';
    std::cout << "1. Filter by lifetime" << '\n';
    std::cout << "2. Filter by nexthop address" << '\n';
    std::cout << "3. Filter by matching with prefix address" << '\n';
    std::cout << "4. Exit the part" << '\n';
    std::cout << "Enter your choice: ";
}

void showParts() {
    std::cout << "======Main menu======" << "\n";
    std::cout << "1. Part1 (sequence filtering)" << '\n';
    std::cout << "2. Part2 (explicit hierarchy filtering)" << '\n';
    std::cout << "3. Part3 (table lookup)" << '\n';
    std::cout << "4. Exit the program" << '\n';
    std::cout << "Enter your choice: ";
}

void showMovementOptions() {
    std::cout << "Chose where to move" << "\n";
    std::cout << "1. To parent" << "\n";
    std::cout << "2. To son" << "\n";
    std::cout << "3. Start filtering" << "\n";
    std::cout << "Enter your choice: ";
}

void showSortingOptions(std::vector<RoutingRecord>& source) {
    std::string confirmation;
    int sortingChoice;
    auto lifetimeComparator = [](RoutingRecord& record1, RoutingRecord& record2) {
        return record1.getLifeTimeSecs() < record2.getLifeTimeSecs();
        };
    auto prefixComparator = [](RoutingRecord& record1, RoutingRecord& record2) {
        return compareIPs(record1.getPrefixAddBits(), record2.getPrefixAddBits(), record1.getPrefixMask(), record2.getPrefixMask());
        };
    std::cout << "Do you want to sort filtered records (y/n): ";
    std::cin >> confirmation;
    if (tolower(confirmation[0]) != 'y') {
        return;
    }
    while (true) {
        std::cout << "Sorting options" << "\n";
        std::cout << "1. Sort by lifetime" << "\n";
        std::cout << "2. Sort by prefix" << "\n";
        std::cout << "Enter your choice: ";
        std::cin >> sortingChoice;
        switch (sortingChoice) {
        case 1:
            Sorter::sort(source, lifetimeComparator);
            return;
        case 2:
            Sorter::sort(source, prefixComparator);
            return;
        default:
            std::cout << "Invalid option. Please select a valid option";
            continue;
        }
    }
}

void printFiltered(std::vector<RoutingRecord>& filteredVector) {
    for (RoutingRecord& record : filteredVector) {
        record.print();
    }
}

int main() {
    initHeapMonitor();
    std::vector<RoutingRecord> records = parseCSV("RT.csv");
    RoutingHierarchy rt(records);
    RoutingTable table(records);
    listType* list = nullptr;
    auto currentNode = RoutingHierarchyIterator(&rt.getHierarchy(), rt.getHierarchy().accessRoot());
    auto end = RoutingHierarchyIterator(&rt.getHierarchy(), nullptr);
    std::vector<RoutingRecord> filtered;
    int choice, inputMask, octetValue, part;
    std::string minimum, maximum, inputAdd, confirmation;
    auto matchWithLifetimeByReference = [&](RoutingRecord& record) {  
       return isTimeInRange(record.getLifeTimeSecs(), minimum, maximum);  
    };  
    auto matchWithAdressByReference = [&](RoutingRecord& record) {  
       return doesIPMatch(record.getPrefixAddBits(), inputMask, ipToUint32(inputAdd));  
    };  
    auto matchWithNextHopByReference = [&](RoutingRecord& record) {  
       return record.getNextHopAdd() == inputAdd;  
    };  
    auto matchWithLifetimeByPointer = [&](RoutingRecord* record) {  
       return isTimeInRange(record->getLifeTimeSecs(), minimum, maximum);  
    };  
    auto matchWithAdressByPointer = [&](RoutingRecord* record) {  
       return doesIPMatch(record->getPrefixAddBits(), inputMask, ipToUint32(inputAdd));  
    };  
    auto matchWithNextHopByPointer = [&](RoutingRecord* record) {  
       return record->getNextHopAdd() == inputAdd;  
    };  
    auto insertToFiltered = [&](RoutingRecord& record) {  
       filtered.push_back(record);  
    };  
    auto insertPointerToFiltered = [&](RoutingRecord* record) {  
       filtered.push_back(*record);  
    };  
    auto processRecordsWithLifetime = [&](RTNode& node) {  
       Filter::filter(node.getPointers().begin(), node.getPointers().end(), matchWithLifetimeByPointer, insertPointerToFiltered);  
    };  
    auto processRecordsWithNextHop = [&](RTNode& node) {  
       Filter::filter(node.getPointers().begin(), node.getPointers().end(), matchWithNextHopByPointer, insertPointerToFiltered);  
    };  
    auto processRecordsWithAddress = [&](RTNode& node) {  
       Filter::filter(node.getPointers().begin(), node.getPointers().end(), matchWithAdressByPointer, insertPointerToFiltered);  
    };  

    auto isLeaf = [&](RTNode& node) {  
       return node.getPointers().size() > 0;  
    };


    while (true) {  
       bool filtering = true;  
       bool navigating = true;  
       showParts();  
       std::cin >> part;  
       switch (part) {  
       case 1:  
           filtered.clear();  
           while (filtering) {  
               showMenu();  
               std::cin >> choice;  

               if (std::cin.fail()) {  
                   std::cin.clear();  
                   std::cin.ignore(10000, '\n');  
                   std::cout << "Invalid input. Please enter a number." << '\n';  
                   continue;  
               }  

               switch (choice) {  
               case 1:  
                   std::cout << "Enter minimum life time (example >> 1w4d3h or 6:25:20): ";  
                   std::cin >> minimum;  
                   std::cout << "Enter maximum life time (example >> 1w4d3h or 6:25:20): ";  
                   std::cin >> maximum;  
                   Filter::filter(records.begin(), records.end(), matchWithLifetimeByReference, insertToFiltered);  
                   showSortingOptions(filtered);
                   printFiltered(filtered);  
                   break;  

               case 2:  
                   std::cout << "Enter a nexthop address (example >> 192.168.1.10): ";  
                   std::cin >> inputAdd;  
                   Filter::filter(records.begin(), records.end(), matchWithNextHopByReference, insertToFiltered);  
                   showSortingOptions(filtered);
                   printFiltered(filtered);  
                   break;  

               case 3:  
                   std::cout << "Enter address you want to match (example >> 192.168.1.10): ";  
                   std::cin >> inputAdd;  
                   std::cout << "Enter max prefix you want to match (1-31): ";  
                   std::cin >> inputMask;  
                   Filter::filter(records.begin(), records.end(), matchWithAdressByReference, insertToFiltered);
                   showSortingOptions(filtered);
                   printFiltered(filtered);  
                   break;  
               case 4:  
                   std::cout << "Are you sure you want to exit? (y/n): ";  
                   std::cin >> confirmation;  
                   if (tolower(confirmation[0]) == 'y') {
                       filtering = false;  
                       std::cout << "Exiting...\n";  
                   }  
                   break;  

               default:  
                   std::cout << "Invalid choice. Try again.\n";  
               }  

               if (choice >= 1 && choice <= 3) {  
                   std::cout << "Filter applied. Current results: " << filtered.size() << " records." << '\n';  
                   filtered.clear();  
               }  
           }  
           break;  
       case 2:
           currentNode = RoutingHierarchyIterator(&rt.getHierarchy(), rt.getHierarchy().accessRoot());
           filtered.clear();  
           while (navigating) {  
               showMovementOptions();  
               std::cin >> choice;  
               switch (choice) {  
               case 1:  
                   currentNode.toParent();  
                   break;  
               case 2:  
                   std::cout << "Enter octet value: ";  
                   std::cin >> octetValue;  
                   currentNode.toSon(octetValue);  
                   break;  
               case 3:  
                   navigating = false;  
                   break;  
               default:  
                   std::cout << "Invalid choice. Try again.\n";  
               }  
           }  
           while (filtering) {  
               showMenu();  
               std::cin >> choice;  

               if (std::cin.fail()) {  
                   std::cin.clear();  
                   std::cin.ignore(10000, '\n');  
                   std::cout << "Invalid input. Please enter a number." << '\n';  
                   continue;  
               }  

               switch (choice) {  
               case 1:  
                   std::cout << "Enter minimum life time (example >> 1w4d3h or 6:25:20): ";  
                   std::cin >> minimum;  
                   std::cout << "Enter maximum life time (example >> 1w4d3h or 6:25:20): ";  
                   std::cin >> maximum;  
                   Filter::filter(currentNode, end, isLeaf, processRecordsWithLifetime);  
                   showSortingOptions(filtered);
                   printFiltered(filtered);  
                   break;  

               case 2:  
                   std::cout << "Enter a nexthop address (example >> 192.168.1.10): ";  
                   std::cin >> inputAdd;  
                   Filter::filter(currentNode, end, isLeaf, processRecordsWithNextHop);
                   showSortingOptions(filtered);
                   printFiltered(filtered);  
                   break;  

               case 3:  
                   std::cout << "Enter address you want to match (example >> 192.168.1.10): ";  
                   std::cin >> inputAdd;  
                   std::cout << "Enter max prefix you want to match (1-31): ";  
                   std::cin >> inputMask;  
                   Filter::filter(currentNode, end, isLeaf, processRecordsWithAddress);
                   showSortingOptions(filtered);
                   printFiltered(filtered);  
                   break;  
               case 4:  
                   std::cout << "Are you sure you want to exit? (y/n): ";  
                   std::cin >> confirmation;  
                   if (tolower(confirmation[0]) == 'y') {
                       filtering = false;  
                       std::cout << "Exiting...\n";  
                   }  
                   break;  

               default:  
                   std::cout << "Invalid choice. Try again.\n";  
               }  

               if (choice >= 1 && choice <= 3) {  
                   std::cout << "Filter applied. Current results: " << filtered.size() << " records." << '\n';  
                   filtered.clear();  
               }  
           }  
           break;
       case 3:
           while (filtering) {
               std::cout << "Enter next-hop address: ";
               std::cin >> inputAdd;
               if (table.getTable().tryFind(inputAdd,list)) {
                   auto foundList = *list;
                   auto it = foundList->begin();
                   while (it != foundList->end()) {
                       auto record = *it;
                       record->print();
                       ++it;
                   }
                   std::cout << "Found " << foundList->size() << " records with this key" << "\n";
               }
               else {
                   std::cout << "There are no records with " << inputAdd << " as key" << "\n";
               }
               std::cout << "Do you want to find other records (y/n): ";
               std::cin >> confirmation;
               if (tolower(confirmation[0]) != 'y') {
                   continue;
               }
               filtering = false;
           }
           break;
       case 4:  
           std::cout << "Are you sure you want to exit? (y/n): ";  
           std::cin >> confirmation;  
           if (tolower(confirmation[0]) != 'y') {
               std::cout << "Exiting...\n";  
               return 0;  
           }  
           break;
       default:  
           std::cout << "Invalid choice. Try again.\n";  
       }  
    }

}
